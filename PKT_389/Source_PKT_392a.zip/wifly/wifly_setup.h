/* ������ Umlaute m�ssen korrekt sichtbar sein, ansonsten Codepageeinstellungen pr�fen */

/*
 * wifly_setup.h
 *
 *  Created on: 02.07.2013
 *      Author: cebra
 */

#ifndef WIFLY_SETUP_H_
#define WIFLY_SETUP_H_


#define WIFLY_APMODE	1
#define WIFLY_ADHOC		2


void Setup_WiFly( void );

#endif /* WIFLY_SETUP_H_ */
