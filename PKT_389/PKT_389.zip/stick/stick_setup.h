/* ������ Umlaute m�ssen korrekt sichtbar sein, ansonsten Codepageeinstellungen pr�fen */

//############################################################################
//# HISTORY  stick_setup.h
//# 
//# 22.05.2013 OG
//# - umgestellt auf menuctrl
//############################################################################

#ifndef _STICK_SETUP_H_
#define _STICK_SETUP_

void Setup_Joysticks(void);

#endif 
